---
sections:
  - title: Libraries
    contracts:
      - ECDSA
      - MerkleProof
---

This collection of libraries provides simple and safe ways to use different cryptographic primitives.
