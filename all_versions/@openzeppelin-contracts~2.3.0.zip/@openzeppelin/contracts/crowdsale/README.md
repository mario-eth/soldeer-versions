---
title: Crowdsales
sections:
  - title: Core
    contracts:
      - Crowdsale
  - subdirectory: emission
  - subdirectory: price
  - subdirectory: validation
  - subdirectory: distribution
---

> This page is incomplete. We're working to improve it for the next release. Stay tuned!
