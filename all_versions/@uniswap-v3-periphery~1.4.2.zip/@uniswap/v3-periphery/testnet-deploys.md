## Uniswap V3 is live on Mainnet

See the addresses [here](./deploys.md).
